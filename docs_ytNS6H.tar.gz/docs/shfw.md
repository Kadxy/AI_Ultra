# 售后服务
::: info
感谢您选择AI Ultra，遇到任何问题，请通过以下方式联系我们
:::

### 方式1：加群
若是基础使用问题，加入[QQ交流群](https://qm.qq.com/cgi-bin/qm/qr?k=qHrlWP7Okj4oW3TrT9lE6FlUbQvoQGTS&jump_from=webapi&authKey=KZGx1EDgckH5IriGMdNyppPnawFGLSKQfdunBV8n1pv0akfX+yXDptMORGf9YIaT)可以更快获得帮助
### 方式2：人工服务
若您遇到其他问题，请联系**QQ：2230318258**，我们会及时处理您的问题
### 方式3：GitHub
进入AI Ultra的[GitHub](https://github.com/Kadxy/AI-Chat-Ultra)页面，提交Issue即可