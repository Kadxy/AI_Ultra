# 基本介绍
::: info
更新日期：2023年9月3日
:::


### 什么是 AI Ultra 学术优化？
基于GitHub开源项目：[gpt_academic](https://github.com/binary-husky/gpt_academic)

我们对原项目进行配置和优化，并部署在AI Ultra服务器，其更容易使用。

### 如何使用
::: warning
AI Ultra 学术优化需先购买**授权密钥**才能使用
:::
1. 前往[统一支付平台](http://pay.wzunjh.top?code=YT0xMSZiPTMx)购买密钥
2. 访问 AI Ultra 学术优化[官网](http://academic.aiutra.com)
3. 将密钥粘贴到对话框并提交，系统自动识别并使用

![](https://tuchuang111025.oss-cn-shenzhen.aliyuncs.com/aa3e3428953afbb864b597ce0c262849.png)