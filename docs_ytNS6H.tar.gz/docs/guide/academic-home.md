---
layout: home
title: AI Ultra 学术优化
hero:
  name: "AI Ultra 学术优化"
  text: "您的私人学术助理"
  tagline: 让未来触手可及 v0.9震撼来袭！
  
  actions:
    - theme: brand
      text: 前往使用
      link: http://academic.aiutra.com
    - theme: alt
      text: 购买令牌
      link: https://pay.wzunjh.top?code=YT0xMSZiPTMx

features:
  - icon: 📑
    title: 功能拓展
    details: 润色/翻译/分析/代码解释/pdf读取/混合调用...

  - icon: 💵
    title: 增值服务
    details: 使用前需先获取授权令牌
    link: https://pay.wzunjh.top?code=YT0xMSZiPTMx
    linkText: 前往购买

  - icon: 📚
    title: 进阶使用手册（建设中）
    details: 了解学术优化站的高级用法
    link: /guide/academic-introduce/
    linkText: 了解更多
---
