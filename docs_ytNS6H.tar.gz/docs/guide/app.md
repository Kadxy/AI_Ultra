# 下载App

### 1.安卓
[点此](https://tuchuang111025.oss-cn-shenzhen.aliyuncs.com/AI%20Ultra%20v5.apk)下载最新版本App

::: info
最新版本：5.0
更新日期：2023年9月3日
:::

### 2.IOS
按照以下步骤，将本站添加到主页
1. 打开Safari浏览器
2. 访问项目地址（https://aiutra.com）
3. 点击菜单栏的“更多”按钮
4. 点击“添加到主屏幕”
![如图](https://tuchuang111025.oss-cn-shenzhen.aliyuncs.com/6735a97f28e5bff1ea5e45cf5691e768.jpg)

### 3.Windows/MacOS
推荐使用**Microsoft Edge**按下图指引添加到主页
![](https://tuchuang111025.oss-cn-shenzhen.aliyuncs.com/2725015686.png)

### 4.其他浏览器
Ctrl+D/Command+D/手动添加到收藏夹